import { useState } from "react";

const SERVICE_TYPES = [
  { id: "purchase", label: "Bought Equipment", icon: "🛒", desc: "You purchased a machine from us" },
  { id: "leasing", label: "Leased Equipment", icon: "📋", desc: "You entered a leasing arrangement" },
  { id: "servicing", label: "Repairs & Servicing", icon: "🔧", desc: "We repaired or maintained your machine" },
];

const ALL_RATINGS = [
  { id: "sales", label: "Sales Experience", icon: "🛒", desc: "How well our team guided your purchase decision", for: ["purchase"] },
  { id: "leasing_process", label: "Leasing Process", icon: "📋", desc: "Clarity, ease and fairness of your lease agreement", for: ["leasing"] },
  { id: "servicing_quality", label: "Servicing Quality", icon: "🔧", desc: "Thoroughness and quality of repairs or maintenance", for: ["servicing"] },
  { id: "response_time", label: "Response Time", icon: "⏱️", desc: "How quickly we addressed your request or fault", for: ["servicing", "purchase", "leasing"] },
  { id: "customer_service", label: "Customer Service", icon: "🤝", desc: "Professionalism and helpfulness of our staff", for: ["purchase", "leasing", "servicing"] },
  { id: "value", label: "Value for Money", icon: "💰", desc: "Fairness of pricing relative to what you received", for: ["purchase", "leasing", "servicing"] },
  { id: "overall", label: "Overall Experience", icon: "⭐", desc: "Your total impression of Printware", for: ["purchase", "leasing", "servicing"] },
];

const STAR_LABELS = ["", "Poor", "Fair", "Good", "Great", "Excellent"];

function StarRating({ value, onChange, hovered, onHover, onLeave }) {
  return (
    <div style={{ display: "flex", gap: "6px", alignItems: "center" }}>
      {[1, 2, 3, 4, 5].map((star) => {
        const active = star <= (hovered || value);
        return (
          <button key={star} onClick={() => onChange(star)}
            onMouseEnter={() => onHover(star)} onMouseLeave={onLeave}
            style={{
              background: "none", border: "none", cursor: "pointer",
              padding: "2px", fontSize: "28px", lineHeight: 1,
              transition: "transform 0.15s",
              transform: active ? "scale(1.18)" : "scale(1)",
              color: active ? "#F5A623" : "#2A2A2A",
            }}>★</button>
        );
      })}
      <span style={{
        marginLeft: "8px", fontSize: "12px", fontFamily: "Courier New, monospace",
        letterSpacing: "0.06em", textTransform: "uppercase",
        color: (hovered || value) ? "#F5A623" : "#444",
        minWidth: "68px", fontWeight: 700,
      }}>{STAR_LABELS[hovered || value] || ""}</span>
    </div>
  );
}

function Tag({ children }) {
  return (
    <div style={{
      display: "inline-block", border: "1px solid #2A2A2A", borderRadius: "4px",
      padding: "5px 16px", fontFamily: "Courier New, monospace", fontSize: "10px",
      letterSpacing: "0.3em", color: "#F5A623", textTransform: "uppercase", marginBottom: "16px",
    }}>{children}</div>
  );
}

const headingStyle = {
  fontSize: "clamp(30px, 5.5vw, 48px)", color: "#F5F0E8",
  margin: "0 0 12px", fontWeight: 400, lineHeight: 1.2, letterSpacing: "-0.01em",
};
const subStyle = {
  color: "#666", fontSize: "15px", lineHeight: 1.7, maxWidth: "420px", margin: "0 auto",
};

function SubmitBtn({ active, onClick, children }) {
  return (
    <button onClick={active ? onClick : undefined} disabled={!active} style={{
      width: "100%", padding: "16px",
      background: active ? "linear-gradient(135deg, #F5A623, #E8940F)" : "#1A1A1A",
      color: active ? "#0D0D0D" : "#333",
      border: "none", borderRadius: "8px", fontSize: "15px",
      fontFamily: "Georgia, serif", fontWeight: 700,
      cursor: active ? "pointer" : "not-allowed",
      letterSpacing: "0.04em", transition: "all 0.3s",
    }}>{children}</button>
  );
}

function StepSelect({ selected, onToggle, onNext }) {
  return (
    <div style={{ animation: "fadeUp 0.5s ease both" }}>
      <div style={{ textAlign: "center", marginBottom: "40px" }}>
        <Tag>Step 1 of 2</Tag>
        <h1 style={headingStyle}>
          What Did You<br />
          <em style={{ color: "#F5A623" }}>Get From Us?</em>
        </h1>
        <p style={subStyle}>Select everything that applies — we'll only ask you to rate what's relevant to you.</p>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "32px" }}>
        {SERVICE_TYPES.map((s) => {
          const active = selected.includes(s.id);
          return (
            <button key={s.id} onClick={() => onToggle(s.id)} style={{
              background: active ? "#1A1700" : "#141414",
              border: `1.5px solid ${active ? "#F5A623" : "#1E1E1E"}`,
              borderRadius: "10px", padding: "18px 22px", cursor: "pointer",
              display: "flex", alignItems: "center", gap: "16px",
              textAlign: "left", transition: "all 0.2s",
            }}>
              <span style={{
                width: "44px", height: "44px", borderRadius: "10px",
                background: active ? "#F5A62320" : "#1A1A1A",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: "22px", flexShrink: 0,
                border: `1px solid ${active ? "#F5A62340" : "#2A2A2A"}`,
              }}>{s.icon}</span>
              <div style={{ flex: 1 }}>
                <div style={{ color: active ? "#F5F0E8" : "#999", fontSize: "16px", fontWeight: 600, marginBottom: "3px" }}>{s.label}</div>
                <div style={{ color: "#555", fontSize: "12px", fontFamily: "monospace" }}>{s.desc}</div>
              </div>
              <div style={{
                width: "22px", height: "22px", borderRadius: "50%",
                border: `2px solid ${active ? "#F5A623" : "#2A2A2A"}`,
                background: active ? "#F5A623" : "transparent",
                display: "flex", alignItems: "center", justifyContent: "center",
                flexShrink: 0, transition: "all 0.2s",
              }}>
                {active && <span style={{ color: "#0D0D0D", fontSize: "13px", fontWeight: 900, lineHeight: 1 }}>✓</span>}
              </div>
            </button>
          );
        })}
      </div>

      <SubmitBtn active={selected.length > 0} onClick={onNext}>
        {selected.length === 0 ? "Select at least one option to continue" : "Continue to Rating →"}
      </SubmitBtn>
    </div>
  );
}

function StepRate({ selectedTypes, onSubmit, onBack }) {
  const [ratings, setRatings] = useState({});
  const [hovered, setHovered] = useState({});
  const [comment, setComment] = useState("");

  const relevant = ALL_RATINGS.filter(r => r.for.some(f => selectedTypes.includes(f)));
  const total = relevant.length;
  const rated = relevant.filter(r => ratings[r.id]).length;
  const allRated = rated === total;

  return (
    <div style={{ animation: "fadeUp 0.4s ease both" }}>
      <div style={{ textAlign: "center", marginBottom: "40px" }}>
        <Tag>Step 2 of 2</Tag>
        <h1 style={headingStyle}>
          How Did We<br />
          <em style={{ color: "#F5A623" }}>Serve You?</em>
        </h1>
        <p style={subStyle}>
          {total} area{total !== 1 ? "s" : ""} to rate, based on what you selected.
        </p>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "16px" }}>
        {relevant.map((r, i) => {
          const val = ratings[r.id] || 0;
          const isRated = val > 0;
          return (
            <div key={r.id} style={{
              background: isRated ? "#141410" : "#141414",
              border: `1px solid ${isRated ? "#2A2510" : "#1E1E1E"}`,
              borderRadius: "10px", padding: "20px 24px",
              transition: "all 0.3s",
              animation: `fadeUp 0.4s ease ${i * 0.06}s both`,
            }}>
              <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: "14px", gap: "12px" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                  <span style={{ fontSize: "22px" }}>{r.icon}</span>
                  <div>
                    <div style={{ color: "#F5F0E8", fontSize: "15px", fontWeight: 600, marginBottom: "2px" }}>{r.label}</div>
                    <div style={{ color: "#555", fontSize: "12px", fontFamily: "monospace" }}>{r.desc}</div>
                  </div>
                </div>
                {isRated && (
                  <div style={{
                    background: "#F5A62320", border: "1px solid #F5A62340",
                    borderRadius: "20px", padding: "3px 10px",
                    fontSize: "11px", fontFamily: "monospace", color: "#F5A623", flexShrink: 0,
                  }}>{val}/5</div>
                )}
              </div>
              <StarRating
                value={val}
                onChange={(v) => setRatings(prev => ({ ...prev, [r.id]: v }))}
                hovered={hovered[r.id] || 0}
                onHover={(v) => setHovered(h => ({ ...h, [r.id]: v }))}
                onLeave={() => setHovered(h => ({ ...h, [r.id]: 0 }))}
              />
            </div>
          );
        })}
      </div>

      <div style={{ background: "#141414", border: "1px solid #1E1E1E", borderRadius: "10px", padding: "20px 24px", marginBottom: "24px" }}>
        <label style={{ display: "block", fontSize: "11px", fontFamily: "monospace", letterSpacing: "0.2em", color: "#555", textTransform: "uppercase", marginBottom: "10px" }}>
          Additional Comments <span style={{ color: "#2A2A2A" }}>(Optional)</span>
        </label>
        <textarea value={comment} onChange={e => setComment(e.target.value)}
          placeholder="Anything else you'd like us to know…" rows={4}
          style={{
            width: "100%", background: "#0D0D0D", border: "1px solid #2A2A2A",
            color: "#F5F0E8", padding: "12px 14px", borderRadius: "6px",
            fontSize: "14px", fontFamily: "Georgia, serif", lineHeight: 1.6,
            resize: "vertical", boxSizing: "border-box",
          }} />
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
          <div style={{ flex: 1, height: "2px", background: "#1E1E1E", borderRadius: "1px", overflow: "hidden" }}>
            <div style={{
              height: "100%", width: `${(rated / total) * 100}%`,
              background: "linear-gradient(90deg, #F5A623, #FFD17C)",
              transition: "width 0.4s ease",
            }} />
          </div>
          <span style={{ fontFamily: "monospace", fontSize: "12px", color: "#555", whiteSpace: "nowrap" }}>{rated}/{total} rated</span>
        </div>

        <SubmitBtn active={allRated} onClick={() => onSubmit(ratings, comment)}>
          {allRated ? "Submit My Ratings →" : `Rate ${total - rated} more to continue`}
        </SubmitBtn>

        <button onClick={onBack} style={{
          background: "transparent", border: "none", color: "#444",
          fontFamily: "monospace", fontSize: "12px", cursor: "pointer",
          letterSpacing: "0.1em", textDecoration: "underline",
        }}>← Change my selections</button>
      </div>
    </div>
  );
}

function StepDone({ ratings, onReset }) {
  const vals = Object.values(ratings);
  const avg = (vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(1);
  return (
    <div style={{ textAlign: "center", animation: "fadeUp 0.6s ease both" }}>
      <div style={{ fontSize: "68px", marginBottom: "16px" }}>🎉</div>
      <Tag>Thank You!</Tag>
      <h2 style={{ ...headingStyle, marginTop: "12px" }}>
        Feedback<br /><em style={{ color: "#F5A623" }}>Received</em>
      </h2>
      <p style={{ color: "#666", fontSize: "15px", lineHeight: 1.7, marginBottom: "32px" }}>
        We appreciate your honest rating.<br />It helps us serve you and everyone better.
      </p>
      <div style={{
        background: "#141414", border: "1px solid #2A2A2A", borderRadius: "12px",
        padding: "28px", marginBottom: "32px", display: "inline-block", minWidth: "200px",
      }}>
        <div style={{ color: "#555", fontSize: "11px", letterSpacing: "0.15em", textTransform: "uppercase", marginBottom: "8px", fontFamily: "monospace" }}>
          Your Average Score
        </div>
        <div style={{ fontSize: "64px", color: "#F5A623", fontWeight: 700, lineHeight: 1 }}>{avg}</div>
        <div style={{ color: "#444", fontSize: "13px", marginTop: "4px", fontFamily: "monospace" }}>out of 5.0</div>
      </div>
      <br />
      <button onClick={onReset} style={{
        background: "transparent", border: "1px solid #2A2A2A", color: "#555",
        padding: "10px 28px", borderRadius: "6px", cursor: "pointer",
        fontSize: "13px", fontFamily: "monospace", letterSpacing: "0.1em",
      }}>Submit Another Response</button>
    </div>
  );
}

export default function App() {
  const [step, setStep] = useState(1);
  const [selectedTypes, setSelectedTypes] = useState([]);
  const [finalRatings, setFinalRatings] = useState({});

  const toggleType = (id) =>
    setSelectedTypes(p => p.includes(id) ? p.filter(x => x !== id) : [...p, id]);

  return (
    <div style={{
      minHeight: "100vh", background: "#0D0D0D",
      fontFamily: "Georgia, serif", padding: "40px 20px 60px",
      position: "relative", overflow: "hidden",
    }}>
      <style>{`
        @keyframes fadeUp { from { opacity:0; transform:translateY(18px); } to { opacity:1; transform:translateY(0); } }
        textarea { outline: none; }
        textarea:focus { border-color: #F5A623 !important; }
      `}</style>

      <div style={{
        position: "fixed", inset: 0, pointerEvents: "none",
        backgroundImage: "radial-gradient(ellipse 80% 50% at 50% -20%, rgba(245,166,35,0.07) 0%, transparent 60%)",
      }} />

      <div style={{ maxWidth: "600px", margin: "0 auto", position: "relative" }}>
        {/* Step indicator */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "8px", marginBottom: "44px" }}>
          {[1, 2, 3].map(n => (
            <div key={n} style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <div style={{
                width: "28px", height: "28px", borderRadius: "50%",
                background: step >= n ? "#F5A623" : "#1A1A1A",
                border: `1.5px solid ${step >= n ? "#F5A623" : "#2A2A2A"}`,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: "12px", fontFamily: "monospace",
                color: step >= n ? "#0D0D0D" : "#444", fontWeight: 700,
                transition: "all 0.3s",
              }}>{n}</div>
              {n < 3 && <div style={{ width: "40px", height: "1px", background: step > n ? "#F5A623" : "#2A2A2A", transition: "background 0.4s" }} />}
            </div>
          ))}
        </div>

        {step === 1 && <StepSelect selected={selectedTypes} onToggle={toggleType} onNext={() => setStep(2)} />}
        {step === 2 && (
          <StepRate
            selectedTypes={selectedTypes}
            onSubmit={(r) => { setFinalRatings(r); setStep(3); }}
            onBack={() => setStep(1)}
          />
        )}
        {step === 3 && <StepDone ratings={finalRatings} onReset={() => { setStep(1); setSelectedTypes([]); setFinalRatings({}); }} />}

        <p style={{ textAlign: "center", color: "#222", fontSize: "11px", fontFamily: "monospace", letterSpacing: "0.1em", marginTop: "40px" }}>
          PRINTWARE COMPANY LIMITED · CONFIDENTIAL FEEDBACK
        </p>
      </div>
    </div>
  );
}
